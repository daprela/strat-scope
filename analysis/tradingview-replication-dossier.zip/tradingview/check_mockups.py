"""Check authored Stage 2D artifacts and record design-only evidence offline."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
root = Path(__file__).resolve().parent
mockups = root / 'ui-artifacts/mockups'
meta = json.loads((mockups / 'mockup-index.json').read_text())
ns = {'s': 'http://www.w3.org/2000/svg'}
rows = meta['frames']
assert len(rows) == 92
assert {f['view'] for f in rows} == set(range(1, 9))
assert {f['state'] for f in rows} == set(range(1, 65))
assert all(f['gate_g5'] in ('PENDING', 'STALE') for f in rows)
current_sources = []
stale_sources = []
allowed_colors = set()
from build_mockups import TOKENS
for pair in TOKENS.values():
    allowed_colors.update((c.upper() for c in pair))
for f in rows:
    source = mockups / f['source_file']
    source_matches = hashlib.sha256(source.read_bytes()).hexdigest() == f['source_sha256']
    if source_matches:
        current_sources.append(f['id'])
    else:
        assert f.get('source_status', '').startswith('STALE_SOURCE'), f['id']
        stale_sources.append(f['id'])
    old = ET.parse(source).getroot()
    oldrects = [tuple((e.get(a) for a in ('x', 'y', 'width', 'height'))) for e in old.findall('.//s:rect', ns)]
    for fn in (f['file'], f['dark_file']):
        p = mockups / fn
        svg = ET.parse(p).getroot()
        rects = [tuple((e.get(a) for a in ('x', 'y', 'width', 'height'))) for e in svg.findall('.//s:rect', ns)]
        if source_matches:
            assert rects == oldrects, (fn, 'geometry drift')
        if source_matches:
            assert svg.get('viewBox') == old.get('viewBox')
        if source_matches:
            assert [(e.get('transform'), e.get('data-role')) for e in svg.findall('.//s:g', ns)] == [(e.get('transform'), e.get('data-role')) for e in old.findall('.//s:g', ns)]
        assert not svg.findall('.//s:script', ns) and (not svg.findall('.//s:foreignObject', ns))
        assert not svg.findall('.//s:image', ns)
        for color in re.findall('#[0-9a-fA-F]{3,6}\\b', p.read_text()):
            assert color.upper() in allowed_colors, (fn, color)
        controls = svg.findall('.//s:g[@data-control]', ns)
        oldcontrols = old.findall('.//s:g[@data-control]', ns)
        if source_matches:
            assert [(e.get('data-control'), e.get('aria-disabled')) for e in controls] == [(e.get('data-control'), e.get('aria-disabled')) for e in oldcontrols]
            for side, pressed in (('Bid', 'true'), ('Ask', 'false')):
                toggles = svg.findall(f'.//s:g[@data-control="{side}"]', ns)
                assert len(toggles) == 1, (fn, side)
                toggle = toggles[0]
                assert toggle.get('role') == 'button'
                assert toggle.get('aria-pressed') == pressed
                assert toggle.get('aria-label') == f'Show/hide {side.lower()} candles'
                assert toggle.get('display') != 'none'
                source_toggle = old.find(f'.//s:g[@data-control="{side}"]', ns)
                assert len(toggle.findall('s:path', ns)) >= len(source_toggle.findall('s:path', ns))

class Links(HTMLParser):

    def __init__(self):
        super().__init__()
        self.links = []
        self.ids = []
        self.executable = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a:
            self.ids.append(a['id'])
        for key in ('href', 'src'):
            if key in a:
                self.links.append(a[key])
        if tag in ('script', 'iframe', 'object', 'embed'):
            self.executable.append(tag)
        if any((k.startswith('on') for k in a)):
            self.executable.append('event handler')
checked_links = 0
html_cache = {}
for p in (mockups / 'index.html', mockups / 'MP-SPEC-001.html', root / 'index.html'):
    parser = Links()
    parser.feed(p.read_text())
    assert not parser.executable if p.parent == mockups else parser.executable == ['script'], (p, parser.executable)
    assert len(parser.ids) == len(set(parser.ids)), p
    for url in parser.links:
        parts = urlsplit(url)
        if parts.scheme or parts.netloc:
            continue
        target = p.parent / unquote(parts.path) if parts.path else p
        assert target.exists(), (p, url)
        checked_links += 1
        if parts.fragment and target.suffix == '.html':
            if target not in html_cache:
                other = Links()
                other.feed(target.read_text())
                html_cache[target] = other
            assert unquote(parts.fragment) in html_cache[target].ids, (p, url)
text = (root / 'ui-dossier.md').read_text()
assert len(re.findall('^\\| UIV-(?!EVID)[A-Z0-9]+-\\d+ \\|', text, re.M)) == 30
assert len(re.findall('^\\| UI-ART-\\d+ \\|', text, re.M)) == 92
assert len(re.findall('^\\| MP-MOCK-\\d+ \\|', text, re.M)) == 92
assert 'G4 `REOPENED / PENDING REVIEW`' in text or 'G4 `SATISFIED`' in text
for match in re.finditer('\\]\\(([^)]+)\\)', text):
    url = match.group(1)
    parts = urlsplit(url)
    if not parts.scheme and parts.path:
        assert (root / unquote(parts.path)).exists(), url
assert len(current_sources) == 92 and not stale_sources
# The user's named product PNG and its authored SVG must agree on canvas size.
import struct
reference = root / 'ui-artifacts/wireframes/previews/WF-FRAME-090-product.png'
assert struct.unpack('>II', reference.read_bytes()[16:24]) == (1870, 884)
reference_svg = ET.parse(reference.with_suffix('.svg')).getroot()
reference_rects = [tuple(e.get(a) for a in ('x', 'y', 'width', 'height'))
                   for e in reference_svg.findall('.//s:rect', ns)]
for number in (90, 91, 92):
    for suffix in ('', '-dark'):
        name = f'MP-MOCK-{number:03}{suffix}-product.svg'
        product = ET.parse(mockups / 'previews' / name).getroot()
        assert product.get('viewBox') == '0 0 1870 884'
        assert [tuple(e.get(a) for a in ('x', 'y', 'width', 'height'))
                for e in product.findall('.//s:rect', ns)] == reference_rects
        capsule = product.find('.//s:g[@data-role="floating-replay-bar"]', ns)
        assert capsule is not None
        assert product.find('.//s:g[@data-role="bottom-dock"]', ns) is None
        if number == 91:
            for action in ('Modify order', 'Cancel order'):
                control = product.find(f'.//s:g[@data-control="{action}"]', ns)
                assert control is not None and control.get('aria-disabled') != 'true'
            assert 'Accepted · waiting; not filled' in ''.join(product.itertext())
        if number == 92:
            for action in ('Start bar', 'Play', 'Step', 'Sell', 'Buy', '[quantity]'):
                control = capsule.find(f'.//s:g[@data-control="{action}"]', ns)
                assert control is not None and control.get('aria-disabled') == 'true'
            assert 'Evaluating event' in ''.join(product.itertext())
record = next(f for f in rows if f['id'] == 'MP-MOCK-090')
assert hashlib.sha256(reference.read_bytes()).hexdigest() == record['matching_product_reference_sha256']
report = {
    'version': meta['version'],
    'kind': 'All-mockup Bid/Ask design revision; no runtime UIV pass or gate approval',
    'current_sources': current_sources,
    'stale_sources': stale_sources,
    'svg_count': 184,
    'source_state_count': 64,
    'source_digest_checks': 'PASS for all current sources',
    'source_rect_geometry_and_canvas': 'PASS for all 184 canonical mockups',
    'command_identity_and_availability_preserved': 'PASS for all 184 canonical mockups',
    'product_reference_canvas_and_rect_geometry': 'PASS: 1870 x 884, light and dark',
    'exact_VIS_palette': 'PASS across all 184 canonical mockups',
    'independent_bid_ask_visibility': 'PASS: labelled adjacent toggles in every theme; Bid pressed / Ask unpressed; four combinations in state specimens',
    'xml_and_no_executable_captured_content': 'PASS',
    'local_links_and_html_fragments': 'PASS',
    'checked_html_links': checked_links,
    'verification_property_count': 30,
    'rendered_preview_count': len(list((mockups / 'previews').glob('*.png'))),
    'visual_inspection': 'Recorded separately in ui-dossier.md Section 21',
    'runtime_evidence': 'UIV-EVID-001–008 expected at implementation; not observed here',
    'g4': 'REOPENED / PENDING REVIEW',
    'g5': 'PENDING; correction does not approve revised wireframes or mockups',
}
(mockups / 'review-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
