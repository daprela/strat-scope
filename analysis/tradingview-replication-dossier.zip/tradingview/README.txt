TradingView Supercharts local replication dossier
Updated 20 October 2026 (all mockups current with r8 Bid/Ask toggles; G4/G5 pending; source inspection 15-16 October)

Open index.html in a browser. It contains the Dukascopy requirements dossier, domain model
and complete architecture dossier with independent review, plus the UI dossier's
Parts I-III interface requirements, interaction flows and view structure,
the canonical visual system with all six direction decisions accepted,
and 92 low-fidelity SVG wireframes (current revision awaiting review) plus 184 high-fidelity light/dark
SVG mockups, offline galleries, visual state specimens and UI verification,
authenticated update, original
analysis, local implementation blueprint, searchable gallery of 62 screenshots (59 controlled + 3 supplemental UI references),
and evidence register. No server or network connection is needed to read it.

AUTHENTICATED-FINDINGS.md    Logged-in observations and revised coverage
requirements-dossier.md     CONVERGED_WITH_ACCEPTED_ASSUMPTIONS; revision 14
domain-model.md             READY_WITH_ACCEPTED_ASSUMPTIONS; revision 1
architecture-dossier.md     IMPLEMENTATION_READY_WITH_NON_BLOCKING_GAPS; revision 2; G1 approved
architecture-review.md      READY WITH NON-BLOCKING CHANGES; 1 MEDIUM verification finding
ui-dossier.md               READY_FOR_HUMAN_WIREFRAME_REVIEW; revision 14; all mockups current against r8; G4 reopened / G5 pending
visual-system.md            READY_FOR_WIREFRAME_DESIGN; revision 2; all six directions accepted
ui-artifacts/wireframes/    WF-SET-001-r8; 92 SVGs, index.html gallery, frame-index.json
build_wireframes.py        Deterministically regenerate authored Stage 2C SVG/gallery artifacts
build_mockups.py           Regenerate Stage 2D paired-theme SVGs/gallery and state specimens
check_mockups.py           Check source geometry, palette, source digests, links and coverage
ui-artifacts/mockups/      MP-SET-001-r3; all 184 canonical SVGs current against r8; Bid/Ask toggles
ui-artifacts/mockups/previews/  26 paired-theme annotated/product PNG review exports
ui-artifacts/mockups/review-checks.json  Artifact checks; no runtime UIV pass claim
ui-artifacts/wireframes/previews/  Workspace/settings/Go to plus replay/paper-trading PNGs
ui-artifacts/reference-screenshots.json  UI-REF-001-003; user-designated A30/A31/A32 PNGs
REPLICATION-ANALYSIS.md     UI specification, data flows, options and gaps
LOCAL-IMPLEMENTATION.md     Architecture, contracts, algorithms and acceptance
FEATURE-INVENTORY.json     Original 11 menu groups / 180 rows
evidence/index.json        Original E01-E18 index (15 October)
evidence/rea-session.json   Original anonymous REA bundle, about 33 MB
evidence/network-summary.json  E01 startup protocol/metadata; unchanged scope
evidence/authenticated-index.json  A01-A35 index (16 October)
evidence/authenticated-review.json  Masked review derivative, not original REA
evidence/authenticated-network-summary.json  Pine probe endpoint metadata only
evidence/authenticated/accessibility/  Masked text, with derivative digests
evidence/authenticated-cleanup.json  Supplementary browser cleanup observations
screenshots/               32 anonymous and 27 authenticated original PNGs
SHA256SUMS                 File SHA-256 manifest
tradingview-replication-dossier.zip  Offline distribution, excluding itself

The requirements dossier inventories the current sibling Dukascopy directory,
all ten assets and eight bar timeframes, plus partial SP500 ticks. Revision 14
includes historical simulated trading, live Dukascopy data and M1/H1 gap filling;
excludes scripting/alerts; and fixes bid-default/ask-selectable chart prices.
Live-account data and completion of affected boundary bars are confirmed.
Charts render bars; ticks resolve intrabar execution, with future tick assets
supported and volume profiles deferred. Finer stored bars precede local ticks;
unresolved SL/TP order uses a labelled stop-first result. Automatic missing-tick
download and permanent database updates are future work; M1/H1 bar gap filling
remains required now. Historical trading supports Market/Limit/Stop, SL/TP,
order modification/cancellation and full/partial closure; opposite entries hedge.
Balance/sizing are configurable without margin checks. SL gaps fill at the first
executable bid/ask. Account currency is fixed USD; fixed quantity and risk-percent
sizing are available. Commission is configurable per instrument as fixed USD per
execution, USD per unit or percent USD notional, default zero, on entry/exit.
All extra slippage modelling is deferred. Orders/modifications use next-event eligibility;
rewind removes later trading actions after confirmation and recomputes the run.
Missing historical USD conversion pauses the affected execution with an
explanation. Acquired bars/candles are retained in application-owned local files;
sibling ingestion files stay unchanged. Layouts, drawings and replay trading
progress autosave/resume. Saved runs preserve original data/results; updated
history applies to new runs or explicit restart. Final history replaces provisional
live-built bars in current history/new runs. Replay trading pauses at unresolved
market-hour gaps; all replay panels follow the historical cursor.
Limits/TP fill at requested price or better;
eligible orders fill fully without liquidity-driven partials. Risk sizing includes
commission and rounds down. Instrument value/price/quantity specifications are
editable and missing required values pause trading. V1 is desktop mouse/keyboard,
at most two charts, no mobile, and no external run-bundle import. Drawings belong
to their layout/instrument and survive trading rewind. Trading uses validated
completed bars/valid ticks; otherwise valid zero-volume/weekend rows are retained.
Execution/recovery/performance packages P1/P2/P3 are accepted. All history must be
accessible, with discovered provider/asset/timeframe/side bounds and no hardcoded
start date. 100k bars/chart is only an in-memory performance working set, never
a total-history/retention/navigation cap. P3 targets: initial viewport <2 seconds
once local inputs are ready; interaction p95 <50 ms; live display within 1 second
of local receipt. Acquisition runs while the app runs, with catch-up on startup
or reconnect. Benchmark two charts, 100k resident bars/chart, four study panes
and 100 drawings on recorded desktop hardware.

The domain model is ready for conditional boundary design under the explicitly
accepted stop-first and full-fill/bar-touch simulation assumptions ASM-01/ASM-02.
It defines concepts, identity/value semantics, ownership, legal transitions,
invariants, preconditions, historical facts, operations and shared policies.
It preserves non-blocking numerical/tool refinements and provider evidence
obligations without selecting architecture or implementation mechanisms.
Actual live-account API/access and provider session/publication behavior still
require integration evidence before live/backfill acceptance. UI/parameter details
remain for downstream design. Human boundary approval at G1 is recorded.
The architecture dossier now includes the approved responsibility boundaries,
workflows, dependencies, ownership and contracts, plus Pass 2 failure/consistency,
concurrency, retry, security, verification, diagnostics and implementation handoff.
Provider access/session evidence, precise numerical/tool conventions, UI details
and technical realization remain explicit prerequisites for affected work under
DEFER-001 through DEFER-007. The readiness verdict does not claim a built/tested
application or completed live integration. The older implementation blueprint
remains a proposal and does not override current requirements/domain/architecture.
The independent architecture review preserves those source documents and records
ADV-VER-001: explicitly verify catalog publication racing with autosave or scoped
run replacement, including preservation of unrelated acknowledged durable state.
No BLOCKING or HIGH findings were established. Existing DEFER prerequisites and
downstream gates remain mandatory; the review does not certify provider/platform
feasibility or a passing implementation. Recommendations are not source revisions.
The UI dossier covers nineteen tasks, fourteen journeys, thirteen interaction
contexts and eight structural views with navigation, semantic regions, action
groups, disclosure, sixty-four material view-state rows and adaptation rules.
Gate G2 was explicitly accepted: every primary task keyboard-operable, WCAG 2.2 AA
target, robust default light/dark themes without an additional color-vision theme,
respect reduced motion, and a 1280x800 CSS-pixel desktop baseline with accessible
zoom/reflow and collapsible secondary regions. The target is not a conformance
claim. Stage 2B visual system is complete: all six direction recommendations were
explicitly accepted on 19 October 2026. Revision 2 defines canonical hierarchy,
typography, light/dark palette, density, surfaces, states, icon/motion language,
chart grammar and semantic tokens. Contrast arithmetic passes; rendered
accessibility verification remains downstream. Stage 2C wireframes are now defined
in UI dossier Part IV: all eight views, 64 state rows, eight zoom/reflow variants
and twenty task/disclosure variants, totaling 92 self-contained SVGs.
The rejected generic task columns are replaced throughout by the persistent
central chart, left drawing strip, top toolbar, right feature rail/drawers
and floating settings/Go to windows plus the replay capsule. Other tasks reserve side/bottom space.
The run bundle viewer launcher is disabled future scope only.
Every chart has the E01 bottom-left range strip and calendar action; frames
086/087 restore the floating A29-style Go to date/custom-range window.
Go to is an explicit exception to the earlier settings-only overlay rule.
Rewind confirmation is inline in replay/work; manual-session report export is
a contextual Results action, not a standalone overlay or future run-bundle viewer.
Viewport navigation never advances the replay cursor. Open
ui-artifacts/wireframes/index.html for review; start with the featured shell,
settings and trading compositions. Frames 088-092 cover replay start selection,
playback, paper order entry, accepted waiting and event processing. Replay
transport and Sell/quantity/Buy now float in one compact capsule, with an A32-traced right paper
ticket and common historical cursor. The three user-designated screenshot
references are separate from the older controlled A30-A32 scenario IDs; no
additional capture session or executed paper trade is asserted.
The recorded G4 approval for WF-SET-001-r6 is historical. The user rejected its
replay/sidebar interpretation; G4 is reopened for WF-SET-001-r8. Review the direct
A32 comparison at ui-artifacts/wireframes/replay-review.html.
Stage 2D supplies MP-SET-001-r1: all 92 compositions in both light and dark themes
(184 SVG files), an offline gallery and keyboard-focus/state specimens. Parts V-VI
contain the canonical artifact registry, 30 UI verification properties, expected
evidence and implementation handoff. Open ui-artifacts/mockups/index.html.
Synthetic fixtures are design examples, not financial facts or product defaults.
Affected MP-SET-001-r1 geometry is stale until reviewed wireframe corrections are
propagated. G5 review resumes afterward; no runtime conformance is asserted. No production application has been built.
Existing scoped DEFER prerequisites and ADV-VER-001 remain outstanding; UX
readiness does not claim provider feasibility, physical durability or implementation.
The external market datasets are not packaged.

Combined evidence: 53 controlled scenarios and 450 steps. These are activity
counts, not product coverage metrics. Failed/cancelled steps are preserved.
The complete authenticated source export is outside this distributable package.
Review text masks account identities/figures and private script identifiers;
selected screenshots retain original pixels and ordinary signed-in UI.
Account balance and EURUSD ticket margin screenshots are excluded.

Working reference evidence now covers RSI, drawings, save/reload, two-chart
interval sync, replay, Pine compile and strategy reports. Alert forms and paper
order-entry surfaces were inspected without alert creation or order submission.
Full Pine compatibility, formula parity, alert delivery, order fills, and many
advanced workflows remain open. No local application was built.

An inspection layout and authored Pine draft state were created in the account.
The inspection tab was closed and the original EURUSD tab preserved after a
temporary browser disconnect. Final simulator logout was not independently
confirmed. See the authenticated findings.

Regeneration from workspace root, entirely offline:
  python analysis/tradingview/extract_evidence.py
  python analysis/tradingview/extract_authenticated_evidence.py
  python analysis/tradingview/build_wireframes.py
  python analysis/tradingview/build_mockups.py --all
  python analysis/tradingview/build_viewer.py
  python analysis/tradingview/check_mockups.py

Extractors use Python's standard library. The viewer builder requires the Python
markdown package. Regenerate SHA256SUMS and the ZIP after changing any files.
For packaging, sort paths relative to this directory, exclude SHA256SUMS,
the ZIP itself, __pycache__, and *.pyc from the checksum inputs; hash each file
with SHA-256 and write SHA256SUMS in sha256sum format. Include those same files
and SHA256SUMS under a tradingview/ prefix in the ZIP. Do not follow symlinks
outside the dossier or include the sibling market-data directory.
Captured DOM/text is untrusted evidence data; no target HTML is executed by the
offline viewer. Preserve the original anonymous bundle independently of updates.

Optional PNG review exports use Inkscape (SVGs remain canonical). For NNN
001, 025, 049, 057, 075, 086-092, run from the workspace root after rebuilding the SVGs:
  inkscape analysis/tradingview/ui-artifacts/wireframes/WF-FRAME-NNN.svg --export-type=png --export-width=1328 --export-filename=analysis/tradingview/ui-artifacts/wireframes/previews/WF-FRAME-NNN.png

Latest correction: WF-SET-001-r7 restores the A31/A32 floating replay bar
and A32 sidebar hierarchy. Frame 090 uses the 1870x884 reference canvas;
1280x800 remains the baseline. Review ui-artifacts/wireframes/replay-review.html.
The previous G4 approval is historical: current corrected geometry is pending
review. Replay/paper mockups based on r6 are marked stale; retain for provenance.

MP-MOCK-090 scoped correction: light/dark now match the user-named
ui-artifacts/wireframes/previews/WF-FRAME-090-product.png at 1870x884.
Open ui-artifacts/mockups/previews/MP-MOCK-090-product.png or
MP-MOCK-090-dark-product.png in the same directory. Canonical annotated SVGs
retain their existing filenames. Floating replay capsule, full-height Order
sidebar and collapsed results match r7; other 182 canonical SVGs are unchanged.
This is a requested design correction, not new G4/G5 approval.

MP-MOCK-091 and 092 now align with 090 in both themes at 1870x884.
091 retains accepted-waiting order inspection and Modify/Cancel; 092 blocks
new decisions during evaluation. Product previews follow the same filenames
with 091/092 in ui-artifacts/mockups/previews/. G4/G5 remain pending.

Toolbar correction: WF-SET-001-r8 adds adjacent independent Bid and Ask
candle-visibility toggles to all 92 frames (Bid on / Ask off pictured).
Both or neither may be shown. All high-fidelity toolbars now match this change in MP-SET-001-r3.

Current high-fidelity set: MP-SET-001-r3, all 92 mockups / both themes
now match WF-SET-001-r8. Adjacent independent Bid/Ask show/hide toggles
retain explicit pressed-state and check-mark cues, Bid on / Ask off pictured.
All four visibility combinations are shown in MP-SPEC-001 in both themes.
Calculation basis, execution side and replay cursor are unchanged by visibility.
Source-staleness is cleared; G4/G5 remain pending. Earlier r1/r2 staleness
notes above are historical and superseded by this complete propagation.
